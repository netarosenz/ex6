/******************
Name: Neta Rosenzweig
ID: 323885582
Assignment: ex.6
*******************/

#include "ex6.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

# define INT_BUFFER 128
#define MAX_POKEMON 151
#define MAX_NAME_LENGTH 20

int main() {
    mainMenu();
    freeAllOwners();
    return 0;
}

void mainMenu() {
    int choice;
    do {
        printf("\n=== Main Menu ===\n");
        printf("1. New Pokedex\n");
        printf("2. Existing Pokedex\n");
        printf("3. Delete a Pokedex\n");
        printf("4. Merge Pokedexes\n");
        printf("5. Sort Owners by Name\n");
        printf("6. Print Owners in a direction X times\n");
        printf("7. Exit\n");
        choice = readIntSafe("Your choice: ");

        switch (choice) {
            case 1:
                openPokedexMenu();
            break;
            case 2:
                if(!ownerHead) {
                    printf("No existing Pokedexes.\n");
                    break;
                }
                enterExistingPokedexMenu();
            break;
            case 3:
                if(!ownerHead) {
                    printf("No existing Pokedexes to delete.\n");
                    break;
                }
                deletePokedex();
            break;
            case 4:
                if(!ownerHead) {
                    printf("Not enough owners to merge.\n");
                    break;
                }
                mergePokedexMenu();
            break;
            case 5:
                if(!ownerHead || !ownerHead->next) {
                    printf("0 or 1 owners only => no need to sort.\n");
                    break;
                }
                sortOwners();
            break;
            case 6:
                if(!ownerHead) {
                    printf("No owners.\n");
                    break;
                }
                printOwnersCircular();
            break;
            case 7:
                printf("Goodbye!\n");
            break;
            default:
                printf("Invalid.\n");
        }
    } while (choice != 7);
}

// ================================================
// Basic struct definitions from ex6.h assumed:
//   PokemonData { int id; char *name; PokemonType TYPE; int hp; int attack; EvolutionStatus CAN_EVOLVE; }
//   PokemonNode { PokemonData* data; PokemonNode* left, *right; }
//   OwnerNode   { char* ownerName; PokemonNode* pokedexRoot; OwnerNode *next, *prev; }
//   OwnerNode* ownerHead;
//   const PokemonData pokedex[];
// ================================================

// --------------------------------------------------------------
// 1) Safe integer reading
// --------------------------------------------------------------

void trimWhitespace(char *str) {
    // Remove leading spaces/tabs/\r
    int start = 0;
    while (str[start] == ' ' || str[start] == '\t' || str[start] == '\r')
        start++;

    if (start > 0) {
        int idx = 0;
        while (str[start])
            str[idx++] = str[start++];
        str[idx] = '\0';
    }

    // Remove trailing spaces/tabs/\r
    int len = (int)strlen(str);
    while (len > 0 && (str[len - 1] == ' ' || str[len - 1] == '\t' || str[len - 1] == '\r')) {
        str[--len] = '\0';
    }
}

char *myStrdup(const char *src) {
    if (!src)
        return NULL;
    size_t len = strlen(src);
    char *dest = (char *)malloc(len + 1);
    if (!dest) {
        printf("Memory allocation failed in myStrdup.\n");
        return NULL;
    }
    strcpy(dest, src);
    return dest;
}

int readIntSafe(const char *prompt)
{
    char buffer[INT_BUFFER];
    int value;
    int success = 0;

    while (!success)
    {
        printf("%s", prompt);

        // If we fail to read, treat it as invalid
        if (!fgets(buffer, sizeof(buffer), stdin))
        {
            printf("Invalid input.\n");
            clearerr(stdin);
            continue;
        }

        // 1) Strip any trailing \r or \n
        //    so "123\r\n" becomes "123"
        size_t len = strlen(buffer);
        if (len > 0 && (buffer[len - 1] == '\n' || buffer[len - 1] == '\r'))
            buffer[--len] = '\0';
        if (len > 0 && (buffer[len - 1] == '\r' || buffer[len - 1] == '\n'))
            buffer[--len] = '\0';

        // 2) Check if empty after stripping
        if (len == 0)
        {
            printf("Invalid input.\n");
            continue;
        }

        // 3) Attempt to parse integer with strtol
        char *endptr;
        value = (int)strtol(buffer, &endptr, 10);

        // If endptr didn't point to the end => leftover chars => invalid
        // or if buffer was something non-numeric
        if (*endptr != '\0')
        {
            printf("Invalid input.\n");
        }
        else
        {
            // We got a valid integer
            success = 1;
        }
    }
    return value;

}

// --------------------------------------------------------------
// 2) Utility: Get type name from enum
// --------------------------------------------------------------
const char *getTypeName(PokemonType type) {
    switch (type) {
    case GRASS:
        return "GRASS";
    case FIRE:
        return "FIRE";
    case WATER:
        return "WATER";
    case BUG:
        return "BUG";
    case NORMAL:
        return "NORMAL";
    case POISON:
        return "POISON";
    case ELECTRIC:
        return "ELECTRIC";
    case GROUND:
        return "GROUND";
    case FAIRY:
        return "FAIRY";
    case FIGHTING:
        return "FIGHTING";
    case PSYCHIC:
        return "PSYCHIC";
    case ROCK:
        return "ROCK";
    case GHOST:
        return "GHOST";
    case DRAGON:
        return "DRAGON";
    case ICE:
        return "ICE";
    default:
        return "UNKNOWN";
    }
}

// --------------------------------------------------------------
// Utility: getDynamicInput (for reading a line into malloc'd memory)
// --------------------------------------------------------------
char *getDynamicInput() {
    char *input = NULL;
    size_t size = 0, capacity = 1;
    input = (char *)malloc(capacity);
    if (!input) {
        printf("Memory allocation failed.\n");
        return NULL;
    }

    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        if (size + 1 >= capacity) {
            capacity *= 2;
            char *temp = (char *)realloc(input, capacity);
            if (!temp) {
                printf("Memory reallocation failed.\n");
                free(input);
                return NULL;
            }
            input = temp;
        }
        input[size++] = (char)c;
    }
    input[size] = '\0';

    // Trim any leading/trailing whitespace or carriage returns
    trimWhitespace(input);

    return input;
}

// Function to print a single Pokemon node
void printPokemonNode(PokemonNode *node) {
    // Check if the node exist
    if (!node) {
        return;
    }
    printf("ID: %d, Name: %s, Type: %s, HP: %d, Attack: %d, Can Evolve: %s\n",
           node->data->id,
           node->data->name,
           getTypeName(node->data->TYPE),
           node->data->hp,
           node->data->attack,
           (node->data->CAN_EVOLVE == CAN_EVOLVE) ? "Yes" : "No");
}

// Creating a new pokemon node
PokemonNode *createPokemonNode(const PokemonData *data) {
    // Check if the data is valid
    if (data == NULL) {
        exit(1);
        }
    // Allocate memory for new pokemon node
    PokemonNode* newNode = (PokemonNode*) malloc(sizeof(PokemonNode));
    // Check if the allocation failed
    if (newNode == NULL) {
        printf("Allocation error.\n");
        exit(1);
    }
    // Allocate memory for the pokemon data
    PokemonData* tempData = (PokemonData*) malloc(sizeof(PokemonData));
    // Check if the allocation failed
    if (tempData == NULL) {
        // Free the memory that already allocated and get out
        free(newNode);
        exit(1);
    }
    // Use temp to keep the data
    *(tempData) = *data;
    newNode->data = tempData;
    // Initialize the left and right pointers
    newNode->left = NULL;
    newNode->right = NULL;
    // return the new node that we created
    return newNode;
}

// Free a single pokemon node
void freePokemonNode(PokemonNode *node) {
    // Check if there is data to free in the node
    if (node == NULL) {
        // If there isn't data to free get out of the func
        return;
    }
    // Free the data in the node
    free(node->data);
    // Finally, free the node itself
    free(node);
}

// Create a new single owner node for the circular linked list
OwnerNode *createOwner(char *ownerName, PokemonNode *starter) {
    // Check if owner name is NULL or empty
    if (ownerName == NULL || ownerName[0] == '\0') {
        return NULL;
    }
    // Check name length
    if (strlen(ownerName) > MAX_NAME_LENGTH) {
        return NULL;
    }
    // Allocate memory for the owner node
    OwnerNode *newNode = malloc(sizeof(OwnerNode));
    // Check if the allocation failed
    if (newNode == NULL) {
        return NULL;
    }
    // Copy the owner name into the new owner node struct
    newNode->ownerName = myStrdup(ownerName);
    // Check if the name copied failed
    if(newNode->ownerName == NULL) {
        // If it's failed, free the memory that already allocated
        free(newNode);
        return NULL;
    }
    // Initialize the pokemon that we already created and placed in the root of the binary tree
    newNode->pokedexRoot = starter;
    // Initialize the pointers of the owner's linked list
    newNode->next = NULL;
    newNode->prev = NULL;
    // The func return the new owner node that just created
    return newNode;
}

// Create the circular linked list of the owners
void linkOwnerInCircularList(OwnerNode *newOwner) {
    // Check if the node exist
    if (newOwner == NULL) {
        return;
    }
    // Check duplicates pokedex names
    if (ownerHead != NULL) {
        OwnerNode *current = ownerHead;
        do {
            if (strcmp(current->ownerName, newOwner->ownerName) == 0) {
            // There is pokedex with this name
            return;
            }
            current = current->next;
            // Stop when all the list was checked
        } while (current != ownerHead);
    }
    // Check if there is any owner in the list
    if (ownerHead == NULL) {
        // The new node will place first in the head of the list
        ownerHead = newOwner;
        // Because there is only single node in the list, it next and previous simultaneously
        newOwner->next = newOwner;
        newOwner->prev = newOwner;
        return;
    }
    // The list isn't empty
    OwnerNode *current = ownerHead;
    // Update the current node that will point to the next node
    do {
        current = current->next;
    // Stop the loop when we arrived again to the head node
    } while (current->next != ownerHead);
    // The new node point forward to the head
    newOwner->next = ownerHead;
    // The new node point back to the last current node
    newOwner->prev = current;
    // The last current node point forward to the new node
    current->next = newOwner;
    // The head point back to the new node
    ownerHead->prev = newOwner;
}

// Search specific owner by name
OwnerNode *findOwnerByName(const char *name) {
    // Check if there is name like the one we search
    if (name == NULL) {
        return NULL;
    }
    // Check if there is any owner in the list
    if (ownerHead == NULL) {
        return NULL;
    }
    // Start the search from the head of the list
    OwnerNode* currentNode = ownerHead;
    do {
        // Compare the name in the current node to the name that we are looking for
        if (strcmp(currentNode->ownerName, name) == 0) {
            // If we found the specific name, return it
            return currentNode;
        }
        // Keep searching and move to the next node
        currentNode = currentNode->next;
        // Stop the loop if we've arrived again to the head of the list
    } while (currentNode != ownerHead);
    // The name not found, return null
    return NULL;
    }

// Create a new pokedex for new owner
void openPokedexMenu() {
    printf("Your name: ");
    // Read the owner name by the function thar read string and print it
    char *ownerName = getDynamicInput();
    // Check if the allocation succeeded
    if (ownerName == NULL) {
        // If the allocation failed, get out of the function
        return;
    }
    // Check if the owner name is already exist
    if (findOwnerByName(ownerName)) {
        printf("Owner '%s' already exists. Not creating a new Pokedex.\n", ownerName);
        // Free the memory of the owner name
        free(ownerName);
        // Get out of the function
        return;
    }
    printf("Choose Starter:\n1. Bulbasaur\n2. Charmander\n3. Squirtle\n");
    // Read the choice by the function thar read numbers
    int choice = readIntSafe("Your choice: ");
    // Check if the choice is valid
    if (choice < 1 || choice > 3) {
        // if isn't valid free the memory of the owner name
        free(ownerName);
        // Get out of the function
        return;
    }
    // Array for the starter ID's
    const int starterPokemonID[] = {1, 4, 7};
    // The array start from 0, fix it by -1
    int pokemonID = starterPokemonID[choice - 1];
    // Create new pokemon node by the data from the array of all the pokemons
    PokemonNode *starterPokemon = createPokemonNode(&pokedex[pokemonID - 1]); // need to write the func from the h file createPokemonNode
    // Check if the allocation succeeded
    if (starterPokemon == NULL) {
        free(ownerName);
        return;
    }
    // Create new owner node
    OwnerNode* newOwner = createOwner(ownerName, starterPokemon);
    // Check if the allocation succeeded
    if (newOwner == NULL) {
        // Free the memory of the starter pokemon
        freePokemonNode(starterPokemon); // need to write the func from the h file freePokemonNode
        // Free the memory of the owner name
        free(ownerName);
        // If the allocation failed, get out of the function
        return;
    }
    linkOwnerInCircularList(newOwner); // need to write the func from the h file linkOwnerInCircularList
    printf("New Pokedex created for %s with starter %s.\n", ownerName, pokedex[pokemonID - 1].name);
    free(ownerName);
}

// Search owner by number
OwnerNode* findOwnerByNumber(int choice) {
    // Check if valid
    if (ownerHead == NULL || choice < 1) {
        return NULL;
    }
    // Start the search from the head of the list
    OwnerNode* current = ownerHead;
    int count = 1;
    // Search all over the circular list
    do {
        // If we found the chosen owner
        if (count == choice) {
            // return this owner
            return current;
        }
        count++;
        // Move to the next owner in the list
        current = current->next;
        // Stop when we arrived again to the head
    } while (current != ownerHead);
    // the chosen owner didn't found
    return NULL;
}

// Place the pokemon node in the right position
PokemonNode *insertPokemonNode(PokemonNode *root, PokemonNode *newNode) {
    // If the root is empty
    if (root == NULL) {
        // The new node become the root of the tree
        return newNode;
    }
    // If the id that we found is the same id in the root
    if (newNode->data->id == root->data->id) {
        // Free the new node
        freePokemonNode(newNode);
        // return the root
        return root;
    }
    // Place the node in the proper position recursively. smaller- to the left, bigger- to the right.
    if (newNode->data->id < root->data->id) {
        root->left = insertPokemonNode(root->left, newNode);
    }
    else if (newNode->data->id > root->data->id) {
        root->right = insertPokemonNode(root->right, newNode);
    }
    // Return the current root
    return root;
}

// Search pokemon by BFS searching
PokemonNode* searchPokemonBFS(PokemonNode* root, int id) {
    // Check if valid
    if (root == NULL || id < 0) {
        return NULL;
    }
    // Create queue for search
    PokemonNode** queue = malloc(MAX_POKEMON * sizeof(PokemonNode*));
    // Check if failed
    if (queue == NULL) {
        return NULL;
    }
    // initial the queue
    int front = 0;
    int rear = 0;
    // Insert the root to queue
    queue[rear++] = root;
    // Search tree
    while (front < rear) {
        // Choose node from the queue
        PokemonNode* current = queue[front++];
        // Check if this is the node we looked for
        if (current->data->id == id) {
            free(queue);
            return current;
        }
        // Insert the 'children' to the queue
        if (current->left && rear < MAX_POKEMON) {
            queue[rear++] = current->left;
        }
        if (current->right && rear < MAX_POKEMON) {
            queue[rear++] = current->right;
        }
    }
    // Free the queue memory
    free(queue);
    // We didn't find the pokemon
    return NULL;
}

// Add pokemon to tree
void addPokemon(OwnerNode *owner) {
    // Check if the owner exist
    if (owner == NULL) {
        return;
    }
    // Get the ID from the user and print it
    int id = readIntSafe("Enter ID to add: ");
    // Check if the ID is valid
    if (id < 1 || id > MAX_POKEMON) {
        printf("Invalid ID.\n");
        return;
    }
    // Check if the pokemon already exist
    PokemonNode* existingPokemon = searchPokemonBFS(owner->pokedexRoot, id);
    // Check if the pointer isn't null
    if (existingPokemon != NULL) {
        printf("Pokemon with ID %d is already in the Pokedex. No changes made.\n", id);
        return;
    }
    // Create new node with the pokemon from the pokedex array according the index
    PokemonNode* newNode = createPokemonNode(&pokedex[id - 1]);
    if (newNode == NULL) {
        exit(1);
    }
    // Insert the new node to the tree
    owner->pokedexRoot = insertPokemonNode(owner->pokedexRoot, newNode);
    printf("Pokemon %s (ID %d) added.\n", pokedex[id - 1].name, id);
}

// Generic BFS function
void BFSGeneric(PokemonNode* root, VisitNodeFunc visit) {
    // Check if valid
    if (root == NULL || visit == NULL) {
        return;
    }
    // Create queue for max pokemons
    PokemonNode** queue = malloc(MAX_POKEMON * sizeof(PokemonNode*));
    if (queue == NULL) {
        return;
    }
    // Queue exit location
    int front = 0;
    // Queue entry location
    int rear = 0;
    // Entry the root to queue
    queue[rear++] = root;
    // While the queue not empty
    while (front < rear) {
        // Remove node from the queue
        PokemonNode* current = queue[front++];
        // Visit at node and print
        visit(current);
        // entry the children to queue if they exist
        if (current->left) {
            queue[rear++] = current->left;
        }
        if (current->right) {
            queue[rear++] = current->right;
        }
    }
    // Free the memory of the queue
    free(queue);
}

// Generic pre-order function
void preOrderGeneric(PokemonNode* root, VisitNodeFunc visit) {
    // Check if valid
    if (visit == NULL) {
        return;
    }
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Visit at the current node
    visit(root);
    // Recursive searching of left sub tree
    preOrderGeneric(root->left, visit);
    // Recursive searching of right sub tree
    preOrderGeneric(root->right, visit);
}

// Generic in-order function
void inOrderGeneric(PokemonNode* root, VisitNodeFunc visit) {
    // Check if valid
    if (visit == NULL) {
        return;
    }
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Recursive searching of left sub tree
    inOrderGeneric(root->left, visit);
    // Visit at the current node
    visit(root);
    // Recursive searching of right sub tree
    inOrderGeneric(root->right, visit);
}

// Generic post-order function
void postOrderGeneric(PokemonNode* root, VisitNodeFunc visit) {
    // Check if valid
    if (visit == NULL) {
        return;
    }
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Recursive searching of left sub tree
    postOrderGeneric(root->left, visit);
    // Recursive searching of right sub tree
    postOrderGeneric(root->right, visit);
    // Visit at the current node
    visit(root);
}

// Display the pokemon in the tree by BFS
void displayBFS(PokemonNode* root) {
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Call to the generic function and print the tree
    BFSGeneric(root, printPokemonNode);
}

// Display the pokemon in the tree by pre-order
void preOrderTraversal(PokemonNode* root) {
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Call to the generic function and print the tree
    preOrderGeneric(root, printPokemonNode);
}

// Display the pokemon in the tree by in-order
void inOrderTraversal(PokemonNode* root) {
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Call to the generic function and print the tree
    inOrderGeneric(root, printPokemonNode);
}

// Display the pokemon in the tree by in-order
void postOrderTraversal(PokemonNode* root) {
    // Check if the tree is empty
    if (root == NULL) {
        return;
    }
    // Call to the generic function and print the tree
    postOrderGeneric(root, printPokemonNode);
}

// Initial the nodes array
void initNodeArray(NodeArray* na, int initialCapacity) {
    // Check that the pointer to the array exist
    if (na == NULL || initialCapacity <= 0) {
        return;
    }
    na->nodes = (PokemonNode**)calloc(initialCapacity, sizeof(PokemonNode*));
    // Check the allocate
    if (na->nodes == NULL) {
        // Initial the array
        na->size = 0;
        na->capacity = 0;
    } else {
        na->size = 0;
        na->capacity = initialCapacity;
    }
}

// מוסיף צומת למערך, מגדיל את המערך אם צריך
void addNode(NodeArray* na, PokemonNode* node) {
    // בדיקות תקינות בסיסיות
    if (na == NULL || node == NULL || na->nodes == NULL) {
        return;
    }
    // אם המערך מלא - נגדיל אותו
    if (na->size == na->capacity) {
        int newCapacity = na->capacity * 2;
        PokemonNode** newNodes = realloc(na->nodes, newCapacity * sizeof(PokemonNode*));
        if (!newNodes) {
            return;
        }
        na->nodes = newNodes;
        na->capacity = newCapacity;
    }
    // הוספת הצומת
    na->nodes[na->size++] = node;
}

// אוסף את כל הצמתים מהעץ למערך (בעזרת preorder למשל)
void collectAll(PokemonNode* root, NodeArray* na) {
    // בדיקה שהמערך קיים
    if (na == NULL || na->nodes == NULL) {
        return;
    }
    if (!root) {
        return;
    }
    addNode(na, root);
    collectAll(root->left, na);
    collectAll(root->right, na);
}

/**
 * @brief Compare function for qsort (alphabetical by node->data->name).
 * @param a pointer to a pointer to PokemonNode
 * @param b pointer to a pointer to PokemonNode
 * @return -1, 0, or +1
 * Why we made it: Sorting by name for alphabetical display.
 */
// פונקציית השוואה בשביל qsort
int compareByNameNode(const void* a, const void* b) {
    // בדיקה שהמצביעים תקינים
    if (a == NULL || b == NULL) {
        return 0;
    }
    // ממירים את המצביעים הגנריים למצביעי PokemonNode*
    PokemonNode* node1 = *(PokemonNode**)a;
    PokemonNode* node2 = *(PokemonNode**)b;
    // בדיקה שהנודים והשמות שלהם קיימים
    if (node1 == NULL || node2 == NULL ||
        node1->data == NULL || node2->data == NULL ||
        node1->data->name == NULL || node2->data->name == NULL) {
        return 0;
        }
    // משווים את השמות
    return strcmp(node1->data->name, node2->data->name);
}

// Sort by Alphabetical
void displayAlphabetical(PokemonNode* root) {
    // Check the tree isn't empty
    if (!root) {
        return;
    }
    // Create the array and initial it
    NodeArray na;
    initNodeArray(&na, MAX_POKEMON);
    if (na.capacity == 0) {
        return;
    }
    // Collect all the nodes to the array
    collectAll(root, &na);
    // Check if the collect failed
    if (na.size == 0) {
        free(na.nodes);
        return;
    }
    // Sort the array by names
    qsort(na.nodes, na.size, sizeof(PokemonNode*), compareByNameNode);
    // Print the nodes sorted
    for(int i = 0; i < na.size; i++) {
        printPokemonNode(na.nodes[i]);
    }
    // Free the sort from memory
    free(na.nodes);
}

/**
 * @brief Show sub-menu to let user pick BFS, Pre, In, Post, or alphabetical.
 * @param owner pointer to Owner
 * Why we made it: We want a simple menu that picks from various traversals.
 */
void displayMenu(OwnerNode *owner) {
    if (owner == NULL) {
        return;
    }
    // Check if there is any pokemons in the tree
    if (!owner->pokedexRoot) {
        printf("Pokedex is empty.\n");
        return;
    }
    // Print the sub menu
    printf("Display:\n");
    printf("1. BFS (Level-Order)\n");
    printf("2. Pre-Order\n");
    printf("3. In-Order\n");
    printf("4. Post-Order\n");
    printf("5. Alphabetical (by name)\n");
    // Get the choice from the user and print it
    int choice = readIntSafe("Your choice: ");
    // Handle the user choice by calling to the proper func
    switch (choice)
    {
        case 1:
            displayBFS(owner->pokedexRoot); // create the generic func
        break;
        case 2:
            preOrderTraversal(owner->pokedexRoot);
        break;
        case 3:
            inOrderTraversal(owner->pokedexRoot);
        break;
        case 4:
            postOrderTraversal(owner->pokedexRoot);
        break;
        case 5:
            displayAlphabetical(owner->pokedexRoot);
        break;
        default:
            printf("Invalid choice.\n");
    }
}

/**
 * @brief Combine BFS search + BST removal to remove Pokemon by ID.
 * @param root BST root
 * @param id the ID to remove
 * @return updated BST root
 * Why we made it: BFS confirms existence, then removeNodeBST does the removal.
 */
PokemonNode* removePokemonByID(PokemonNode* root, int id) {
    // Check if the tree is empty
    if (root == NULL) {
        return NULL;
    }
    // Search the node
    if (id < root->data->id) {
        root->left = removePokemonByID(root->left, id);
    }
    else if (id > root->data->id) {
        root->right = removePokemonByID(root->right, id);
    }
    // We found the node to remove
    else {
        // Case 1: there is no children or there is 1 child
        if (root->left == NULL) {
            PokemonNode* temp = root->right;
            freePokemonNode(root);
            return temp;
        }
        else if (root->right == NULL) {
            PokemonNode* temp = root->left;
            freePokemonNode(root);
            return temp;
        }
        // Case 2: 2 children- find the bigger child from the right sub tree
        PokemonNode* successor = root->right;
        while (successor->left != NULL) {
            successor = successor->left;
        }
        // Copy the data from the child
        PokemonData* tempData = root->data;
        root->data = successor->data;
        successor->data = tempData;
        // Delete the child
        root->right = removePokemonByID(root->right, successor->data->id);
    }
    return root;
}

/**
 * @brief Free one PokemonNode (including name).
 * @param node pointer to node
 * Why we made it: Avoid memory leaks for single nodes.
 */
void freePokemon(OwnerNode* owner) {
    // 1. בדיקות תקינות
    if (owner == NULL || owner->pokedexRoot == NULL) {
        printf("No Pokemon to release.\n");
        return;
    }

    // 2. קבלת ID מהמשתמש
    int id = readIntSafe("Enter Pokemon ID to release: ");

    // 3. בדיקה אם הפוקימון קיים
    PokemonNode* pokemon = searchPokemonBFS(owner->pokedexRoot, id);
    if (pokemon == NULL) {
        printf("No Pokemon with ID %d found.\n", id);
        return;
    }

    // 4. מחיקת הפוקימון מהעץ
    printf("Removing Pokemon %s (ID %d).\n", pokemon->data->name, id);
    owner->pokedexRoot = removePokemonByID(owner->pokedexRoot, id);
}

/**
 * @brief Let user pick two Pokemon by ID in the same Pokedex to fight.
 * @param owner pointer to the Owner
 * Why we made it: Fun demonstration of BFS and custom formula for battles.
 */
void pokemonFight(OwnerNode* owner) {
    // בדיקת תקינות
    if (owner == NULL || owner->pokedexRoot == NULL) {
        printf("Pokedex is empty.\n");
        return;
    }

    // קבלת ID של הפוקימונים
    int id1 = readIntSafe("Enter ID of the first Pokemon: ");
    int id2 = readIntSafe("Enter ID of the second Pokemon: ");

    // מציאת הפוקימונים
    PokemonNode* pokemon1 = searchPokemonBFS(owner->pokedexRoot, id1);
    PokemonNode* pokemon2 = searchPokemonBFS(owner->pokedexRoot, id2);

    // בדיקה שהפוקימונים נמצאו
    if (pokemon1 == NULL || pokemon2 == NULL) {
        printf("One or both Pokemon IDs not found.\n");
        return;
    }

    // חישוב הציונים
    double score1 = pokemon1->data->attack * 1.5 + pokemon1->data->hp * 1.2;
    double score2 = pokemon2->data->attack * 1.5 + pokemon2->data->hp * 1.2;

    // הדפסת התוצאות והכרזה על המנצח
    printf("Pokemon 1: %s (Score = %.2f)\n", pokemon1->data->name, score1);
    printf("Pokemon 2: %s (Score = %.2f)\n", pokemon2->data->name, score2);

    if (score1 > score2) {
        printf("%s wins!\n", pokemon1->data->name);
    } else if (score2 > score1) {
        printf("%s wins!\n", pokemon2->data->name);
    } else {
        printf("It's a tie!\n");
    }
}

/**
 * @brief Evolve a Pokemon (ID -> ID+1) if allowed.
 * @param owner pointer to the Owner
 * Why we made it: Demonstrates removing an old ID, inserting the next ID.
 */
void evolvePokemon(OwnerNode* owner) {
    // בדיקות תקינות
    if (owner == NULL || owner->pokedexRoot == NULL) {
        printf("Cannot evolve. Pokedex empty.\n");
        return;
    }

    // קבלת ID מהמשתמש
    int id = readIntSafe("Enter ID of Pokemon to evolve: ");

    // מציאת הפוקימון
    PokemonNode* pokemon = searchPokemonBFS(owner->pokedexRoot, id);
    if (pokemon == NULL) {
        printf("Pokemon with ID %d not found.\n", id);
        return;
    }

    // בדיקה אם יכול להתפתח
    if (pokemon->data->CAN_EVOLVE != CAN_EVOLVE) {
        printf("Pokemon %s cannot evolve.\n", pokemon->data->name);
        return;
    }

    // שמירת השם לפני כל שינוי
    char* originalName = myStrdup(pokemon->data->name);
    if (originalName == NULL) {
        // טיפול במקרה של כשל בהקצאת זיכרון
        printf("Memory allocation failed.\n");
        return;
    }

    // בדיקה אם הצורה המפותחת כבר קיימת
    PokemonNode* evolvedForm = searchPokemonBFS(owner->pokedexRoot, id + 1);

    // וודא שיש פוקימון מפותח בטווח המערך
    if (id < 1 || id >= MAX_POKEMON) {
        printf("Cannot evolve this Pokemon.\n");
        free(originalName);
        return;
    }

    // מציאת הפוקימון המפותח
    const PokemonData* evolvedData = NULL;
    for (int i = 0; i < MAX_POKEMON; i++) {
        if (pokedex[i].id == id + 1) {
            evolvedData = &pokedex[i];
            break;
        }
    }

    if (evolvedData == NULL) {
        printf("No evolution found for Pokemon with ID %d.\n", id);
        free(originalName);
        return;
    }

    // הדפס הסרת הפוקימון המקורי
    printf("Removing Pokemon %s (ID %d).\n", originalName, id);

    // מחיקת הפוקימון המקורי
    owner->pokedexRoot = removePokemonByID(owner->pokedexRoot, id);

    // הדפסת ההתפתחות
    printf("Pokemon evolved from %s (ID %d) to %s (ID %d).\n",
           originalName, id, evolvedData->name, id + 1);

    // אם הצורה המפותחת כבר קיימת, לא צריך להוסיף
    if (evolvedForm == NULL) {
        // יצירת צומת חדש עם הפוקימון המפותח
        PokemonNode* newNode = createPokemonNode(evolvedData);
        if (newNode != NULL) {
            PokemonNode* insertedNode = insertPokemonNode(owner->pokedexRoot, newNode);
            if (insertedNode != owner->pokedexRoot) {
                // הוספה הצליחה
                owner->pokedexRoot = insertedNode;
            } else {
                // הוספה נכשלה (כנראה בגלל כפילות)
                printf("Failed to insert evolved Pokemon.\n");
                // שחרור הצומת שנוצר
                freePokemonNode(newNode);
            }
        }
        else {
            printf("Failed to create evolved Pokemon node.\n");
        }
    }

    // שחרור הזיכרון שהוקצה
    free(originalName);
}

/**
 * @brief Let user pick an existing Pokedex (owner) by number, then sub-menu.
 * Why we made it: This is the main interface for adding/fighting/evolving, etc.
 */
void enterExistingPokedexMenu() {
    // Check if there is any owner in the list
    if (ownerHead == NULL) {
        return;
    }
    printf("\nExisting Pokedexes:\n");
    // Initialize owners count to start from the first owner
    int count = 1;
    // Start the list from the head
    OwnerNode* currentOwner = ownerHead;
    // Print the exist owners and update the count
    do {
        printf("%d. %s\n", count, currentOwner->ownerName);
        count++;
        currentOwner = currentOwner->next;
        //Stop to print when we arrived again to the start of the list
    } while (currentOwner != ownerHead);
    // Get the chosen owner from the user and print it
    int choice = readIntSafe("Choose a Pokedex by number: ");
    // Casting the number of the owner to the name of the owner
    OwnerNode* chosenOwner = findOwnerByNumber(choice);
    // Check if the chosen owner point to null
    if (chosenOwner == NULL) {
        return;
    }
    printf("\nEntering %s's Pokedex...\n", chosenOwner->ownerName);
    int subChoice;
    // Print the sub menu
    do
    {
        printf("\n-- %s's Pokedex Menu --\n", chosenOwner->ownerName);
        printf("1. Add Pokemon\n");
        printf("2. Display Pokedex\n");
        printf("3. Release Pokemon (by ID)\n");
        printf("4. Pokemon Fight!\n");
        printf("5. Evolve Pokemon\n");
        printf("6. Back to Main\n");
        // Get the choice from the user and print it
        subChoice = readIntSafe("Your choice: ");
        // Handle the user's choice
        switch (subChoice)
        {
            case 1:
                addPokemon(chosenOwner);
            break;
            case 2:
                displayMenu(chosenOwner);
            break;
            case 3:
                freePokemon(chosenOwner);
            break;
            case 4:
                pokemonFight(chosenOwner);
            break;
            case 5:
                evolvePokemon(chosenOwner);
            break;
            case 6:
                printf("Back to Main Menu.\n");
            break;
            default:
                printf("Invalid choice.\n");
        }
    } while (subChoice != 6);
}

/**
 * @brief Recursively free a BST of PokemonNodes.
 * @param root BST root
 * Why we made it: Clearing a user’s entire Pokedex means freeing a tree.
 */
void freePokemonTree(PokemonNode* root) {
    // Case base: if the tree is empty
    if (root == NULL) {
        return;
    }
    // Free recursively the sub-trees, left and right
    freePokemonTree(root->left);
    freePokemonTree(root->right);
    // Free the current node by the free function
    freePokemonNode(root);
}

/**
 * @brief Remove a specific OwnerNode from the circular list, possibly updating head.
 * @param target pointer to the OwnerNode
 * Why we made it: Deleting or merging owners requires removing them from the ring.
 */
void removeOwnerFromCircularList(OwnerNode* target) {
    // בדיקות תקינות
    if (target == NULL || ownerHead == NULL) {
        return;
    }

    // בדיקה שהבעלים קיים ברשימה
    OwnerNode* current = ownerHead;
    do {
        if (current == target) {
            break;  // מצאנו את הצומת
        }
        current = current->next;
    } while (current != ownerHead);

    // אם סיימנו את הסריקה ללא מציאת הצומת, צא
    if (current != target) {
        return;
    }

    // מקרה 1: יש רק בעלים אחד ברשימה
    if (target->next == target) {
        ownerHead = NULL;
        return;
    }

    // מקרה 2: מחיקת הראש
    if (target == ownerHead) {
        ownerHead = ownerHead->next;
    }

    // מקרה 3: עדכון המצביעים של השכנים
    target->prev->next = target->next;
    target->next->prev = target->prev;

    // נתק את המצביעים של הצומת המוסר
    target->next = NULL;
    target->prev = NULL;
}

/**
 * @brief Free an OwnerNode (including name and entire Pokedex BST).
 * @param owner pointer to the owner
 * Why we made it: Deleting an owner also frees their Pokedex & name.
 */
void freeOwnerNode(OwnerNode* owner) {
    // בדיקת תקינות
    if (owner == NULL) {
        return;
    }

    // שחרור שם הבעלים
    if (owner->ownerName != NULL) {
        free(owner->ownerName);
    }

    if (owner->pokedexRoot != NULL) {
        freePokemonTree(owner->pokedexRoot);
    }

    // שחרור הצומת עצמו
    free(owner);
}

/**
 * @brief Delete an entire Pokedex (owner) from the list.
 * Why we made it: Let user pick which Pokedex to remove and free everything.
 */
void deletePokedex() {
    // בדיקה שיש פוקדקסים בכלל
    if (ownerHead == NULL) {
        return;
    }

    printf("\n=== Delete a Pokedex ===\n");

    // ספירת מספר הבעלים
    int totalOwners = 0;
    OwnerNode* current = ownerHead;
    do {
        totalOwners++;
        current = current->next;
    } while (current != ownerHead);


    // הצגת הרשימה המעגלית של הבעלים
    current = ownerHead;
    int count = 1;
    do {
        printf("%d. %s\n", count++, current->ownerName);
        current = current->next;
    } while (current != ownerHead);

    // קבלת בחירת המשתמש
    int choice = readIntSafe("Choose a Pokedex to delete by number: ");

    // בדיקת תקינות הבחירה
    if (choice < 1 || choice > totalOwners) {
        printf("Invalid Pokedex selection.\n");
        return;
    }

    // מציאת הבעלים לפי הבחירה
    OwnerNode* ownerToDelete = findOwnerByNumber(choice);
    if (ownerToDelete == NULL) {
        return;
    }

    printf("Deleting %s's entire Pokedex...\n", ownerToDelete->ownerName);

    // מחיקת עץ הפוקימונים של הבעלים
    freePokemonTree(ownerToDelete->pokedexRoot);
    ownerToDelete->pokedexRoot = NULL;  // הוספת סימון שהעץ כבר משוחרר

    // מחיקת הבעלים מהרשימה המעגלית
    removeOwnerFromCircularList(ownerToDelete);

    // שחרור הזיכרון של הבעלים עצמו
    freeOwnerNode(ownerToDelete);

    printf("Pokedex deleted.\n");
}

// Move all the pokemons from the first owner to the second owner
void mergeTrees(OwnerNode* firstOwner, OwnerNode* secondOwner) {
    // אם העץ השני ריק, אין מה למזג
    if (secondOwner->pokedexRoot == NULL) {
        return;
    }

    // יצירת תור ל-BFS
    PokemonNode** queue = malloc(MAX_POKEMON * sizeof(PokemonNode*));
    if (queue == NULL) {
        return;
    }

    int indexToRemove = 0;
    int indexToInsert = 0;
    int failedInsertions = 0;

    // מכניסים את השורש של העץ השני לתור
    queue[indexToInsert ++] = secondOwner->pokedexRoot;

    // עוברים על כל הצמתים בעץ השני
    while (indexToRemove  < indexToInsert ) {
        PokemonNode* current = queue[indexToRemove ++];

        // יצירת עותק של הפוקימון הנוכחי
        PokemonNode* newNode = createPokemonNode(current->data);

        // הכנסה לעץ הראשון
        if (newNode != NULL) {
            PokemonNode* insertResult = insertPokemonNode(firstOwner->pokedexRoot, newNode);
            if (insertResult == firstOwner->pokedexRoot) {
                // הוספה נכשלה (כנראה בגלל כפילות)
                failedInsertions++;
            }
            else {
                firstOwner->pokedexRoot = insertResult;
            }
        }
        else {
            failedInsertions++;
        }

        // הכנסת הילדים לתור
        if (current->left && indexToInsert < MAX_POKEMON) {
            queue[indexToInsert++] = current->left;
        }
        if (current->right && indexToInsert < MAX_POKEMON) {
            queue[indexToInsert++] = current->right;
        }
    }

    // שחרור התור
    free(queue);
}

// פונקציית עזר לספירת מספר הפוקימונים בעץ
int countPokemonInTree(PokemonNode* root) {
    if (root == NULL) {
        return 0;
    }

    return 1 +
           countPokemonInTree(root->left) +
           countPokemonInTree(root->right);
}

/**
 * @brief Merge the second owner's Pokedex into the first, then remove the second owner.
 * Why we made it: BFS copy demonstration plus removing an owner.
 */
void mergePokedexMenu() {
    // בדיקה שיש מספיק בעלים למיזוג
    if (ownerHead == NULL || ownerHead->next == ownerHead) {
        printf("Not enough owners to merge.\n");
        return;
    }

    printf("\n=== Merge Pokedexes ===\n");

    // קבלת שמות הבעלים
    printf("Enter name of first owner: ");
    char* firstName = getDynamicInput();
    if (firstName == NULL || strlen(firstName) == 0) {
        free(firstName);
        return;
    }
    printf("Enter name of second owner: ");
    char* secondName = getDynamicInput();
    if (secondName == NULL || strlen(secondName) == 0) {
        free(firstName);
        free(secondName);
        return;
    }

    // מציאת הבעלים
    OwnerNode* firstOwner = findOwnerByName(firstName);
    OwnerNode* secondOwner = findOwnerByName(secondName);

    // שחרור הזיכרון של המחרוזות
    free(firstName);
    free(secondName);

    // בדיקה שהבעלים נמצאו
    if (firstOwner == NULL || secondOwner == NULL) {
        printf("One or both owners not found.\n");
        return;
    }

    // בדיקה שלא מנסים למזג אותו בעלים
    if (firstOwner == secondOwner) {
        return;
    }

    printf("Merging %s and %s...\n", firstOwner->ownerName, secondOwner->ownerName);

    // מספר הפוקימונים לפני המיזוג
    int initialFirstCount = countPokemonInTree(firstOwner->pokedexRoot);


    // העברת כל הפוקימונים מהבעלים השני לראשון
    mergeTrees(firstOwner, secondOwner);
    printf("Merge completed.\n");

    // בדיקת הצלחת המיזוג
    int finalFirstCount = countPokemonInTree(firstOwner->pokedexRoot);

    if (finalFirstCount <= initialFirstCount) {
        printf("Merge failed. No Pokemon were transferred.\n");
        return;
    }

        // מחיקת הבעלים השני
        printf("Owner '%s' has been removed after merging.\n", secondOwner->ownerName);
        removeOwnerFromCircularList(secondOwner);
        freeOwnerNode(secondOwner);
}

/**
 * @brief Helper to swap name & pokedexRoot in two OwnerNode.
 * @param a pointer to first owner
 * @param b pointer to second owner
 * Why we made it: Used internally by bubble sort to swap data.
 */
// Swap the data of pokemon pair
void swapOwnerData(OwnerNode *a, OwnerNode *b){
    char* tempName = a->ownerName;
    a->ownerName = b->ownerName;
    b->ownerName = tempName;

    // החלפת עצי פוקימונים
    PokemonNode* tempTree = a->pokedexRoot;
    a->pokedexRoot = b->pokedexRoot;
    b->pokedexRoot = tempTree;
}

/**
 * @brief Sort the circular owners list by name.
 * Why we made it: Another demonstration of pointer manipulation + sorting logic.
 */
void sortOwners() {
    // בדיקה שיש מספיק בעלים למיון
    if (ownerHead == NULL || ownerHead->next == ownerHead) {
        return;
    }

    int swapped;
    OwnerNode *current;

    do {
        swapped = 0;
        current = ownerHead;

        // עובר על כל זוג צמוד ברשימה
        do {
            // אם הסדר לא נכון - מחליף
            if (strcmp(current->ownerName, current->next->ownerName) > 0) {
                swapOwnerData(current, current->next);
                swapped = 1;
            }
            current = current->next;
        } while (current->next != ownerHead);

    } while (swapped);

    printf("Owners sorted by name.\n");
}

/**
 * @brief Print owners left or right from head, repeating as many times as user wants.
 * Why we made it: Demonstrates stepping through a circular list in a chosen direction.
 */
void printOwnersCircular() {
    // בדיקה שיש בעלים להדפיס
    if (ownerHead == NULL) {
        printf("No owners.\n");
        return;
    }

    // קבלת הכיוון
    printf("Enter direction (F or B): ");
    char* direction = getDynamicInput();

    // בדיקת הקצאת זיכרון
    if (direction == NULL) {
        return;
    }

    // בדיקת אורך הקלט
    if (strlen(direction) != 1) {
        printf("Direction must be a single character (F or B).\n");
        free(direction);
        return;
    }

    // בדיקת תקינות הכיוון
    if (direction == NULL || (direction[0] != 'F' && direction[0] != 'f' &&
        direction[0] != 'B' && direction[0] != 'b')) {
        printf("Invalid direction.\n");
        free(direction);
        return;
        }

    // קבלת וודיקת תקינות מספר ההדפסות
    int numPrints = readIntSafe("How many prints? ");
    if (numPrints <= 0) {
        printf("Number of prints must be positive.\n");
        free(direction);
        return;
    }

    OwnerNode* current = ownerHead;
    for (int i = 1; i <= numPrints; i++) {
        printf("[%d] %s\n", i, current->ownerName);

        // התקדמות בכיוון הנכון
        if (direction[0] == 'F' || direction[0] == 'f') {
            current = current->next;
        } else if (direction[0] == 'B' || direction[0] == 'b') {
            current = current->prev;
        }
    }

    // שחרור זיכרון
    free(direction);
}

/**
 * @brief Frees every remaining owner in the circular list, setting ownerHead = NULL.
 * Why we made it: Ensures a squeaky-clean exit with no leftover memory.
 */
void freeAllOwners() {
    // אם הרשימה ריקה
    if (ownerHead == NULL) {
        return;
    }

    // אם יש רק בעלים אחד
    if (ownerHead->next == ownerHead) {
        // שחרור העץ שלו
        freePokemonTree(ownerHead->pokedexRoot);
        // שחרור הבעלים עצמו
        freeOwnerNode(ownerHead);
        ownerHead = NULL;
        return;
    }

    // אם יש יותר מבעלים אחד
    OwnerNode* current = ownerHead;
    OwnerNode* next;

    do {
        next = current->next;  // שומרים את הבא בתור
        freeOwnerNode(current);  // משחררים את העץ
        current = next;  // עוברים לבא
    } while (current != ownerHead);

    ownerHead = NULL;
}
